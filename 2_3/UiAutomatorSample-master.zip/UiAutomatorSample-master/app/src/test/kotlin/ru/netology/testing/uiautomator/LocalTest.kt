package ru.netology.testing.uiautomator

import org.junit.Assert.assertEquals
import org.junit.Test

class LocalTest {

    @Test
    fun justTest() {
        assertEquals(true, true)
    }
}